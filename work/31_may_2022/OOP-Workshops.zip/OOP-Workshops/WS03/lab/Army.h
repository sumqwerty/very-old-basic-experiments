#ifndef SDDS_ARMY_H_
#define SDDS_ARMY_H_
namespace sdds {
    const int MAX_NAME_LEN = 50;
    class Army{
        private:
            char nationality[MAX_NAME_LEN];
            int units;
            double power;
        
        public:
            void setEmpty();
            void createArmy(const char* country, double pow, int troops);
            void updateUnits(int troops);
            const char* checkNationality() const;
            int checkCapacity() const;
            double checkPower() const;
            bool isEmpty() const;
            bool isStrongerThan(const Army& army)const;
        
    };

    void battle( Army& arm1, Army& arm2);
    
    void displayDetails(const Army* armies, int size);

}
#endif 