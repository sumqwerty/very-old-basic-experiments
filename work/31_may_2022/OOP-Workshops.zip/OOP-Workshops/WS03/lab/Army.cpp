#include <cstring>
#include <iostream>
#include <iomanip>
#include "Army.h"

using namespace std;

namespace sdds{
    void Army::setEmpty(){
        strcpy(nationality,"");
        units = 0;
    }
    void Army::createArmy(const char* country, double pow, int troops){
        cout << fixed << setprecision(1);
        if(country != nullptr && strlen(country)>0 && pow > 0 && troops > 0){
            strcpy(nationality, country);
            power = pow;
            units = troops;
        }
        else{
            setEmpty();
        }
    }

    void Army::updateUnits(int troops){
        units += troops;
        power += (((double)troops) * 0.25);
    }

    const char* Army::checkNationality() const{
        return nationality;   
    }

    int Army::checkCapacity() const{
        return units;
    }
    
    double Army::checkPower() const{
        return power;
    }

    bool Army::isEmpty() const{
        if(strcmp(nationality,"") == 0 && units == 0)return true;
        return false;
    }

    bool Army::isStrongerThan(const Army& army)const{
        if(army.checkPower() < power)return true;
        return false;
    }

    void battle( Army& arm1, Army& arm2){
        if(!arm1.isEmpty() && !arm2.isEmpty()){
            if(arm1.isStrongerThan(arm2)){
                cout<<"In battle of "<<arm1.checkNationality()<<" and "<<arm2.checkNationality()<<", "<<arm1.checkNationality()<<" is victorious!"<<endl;
                arm2.updateUnits( (int)(-arm2.checkCapacity()/2) );

            }else {
                cout<<"In battle of "<<arm1.checkNationality()<<" and "<<arm2.checkNationality()<<", "<<arm2.checkNationality()<<" is victorious!"<<endl;
                arm1.updateUnits( (int)(-arm1.checkCapacity()/2) );
            }
        }
    }

    void displayDetails(const Army* armies, int size){
        cout<<"Armies reporting to battle:\n";
        for(int i=0; i<size; ++i){
            if(!armies[i].isEmpty()){
                // Nationality: XXXXXXXXXXX, Units Count: XXXX, Power left: XXXXX
                cout<<"Nationality: "<<armies[i].checkNationality()<<", Units Count: "<<armies[i].checkCapacity()<<", Power left: "<<armies[i].checkPower()<<endl;
            }
        }
    }
}