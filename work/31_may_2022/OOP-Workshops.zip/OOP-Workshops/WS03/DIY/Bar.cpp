#include "Bar.h"
#include <cstring>
#include <iostream>

using namespace std;

namespace sdds{
    void Bar::setEmpty(){
        strcpy(title,"");
        fill = '\0';
        value = 0;
    }

    void Bar::set(const char *_title, char _fill, int _value){

        if(_value < 0 || _value > 100) state = false;
        
        else{
            strcpy(title,_title);
            fill = _fill;
            value = _value;
            state = true;
        }
    }

    bool Bar::isValid() const{
        return state;
    }

    void Bar::draw() const{
        if(isValid()){
            int dots = 20 - strlen(title);
            cout<<title;
            for(int i=0; i<dots; ++i)cout<<".";
            cout<<"|";
            int bars = value/2;
            for(int i=0; i<bars; ++i)cout<<fill;
            cout<<endl;
        }
    }

}