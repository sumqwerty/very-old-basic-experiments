#ifndef SDDS_BARCHART_H_
#define SDDS_BARCHART_H_

#include "Bar.h"

namespace sdds{
    class BarChart{
        private:
            char *chartTitle;
            Bar *bar;
            char fillChar;
            int chartSize;
            int currSize;
        public:
            void init(const char* title, int noOfSampels, char fill);
            void add(const char* bar_title, int value);
            void draw()const;
            void deallocate();
            bool isValid()const;
    };
}
#endif