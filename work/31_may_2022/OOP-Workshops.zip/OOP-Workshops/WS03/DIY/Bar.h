#ifndef SDDS_BAR_H_
#define SDDS_BAR_H_

namespace sdds{
    class Bar{
        private:
            char title[20];
            char fill;
            int value;
            bool state;

        public:
            void draw() const;
            void setEmpty();
            void set(const char *_title, char _fill, int _value);
            bool isValid() const;

    };
}
#endif