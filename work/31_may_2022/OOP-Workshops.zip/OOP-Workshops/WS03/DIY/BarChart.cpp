#include <iostream>
#include <cstring>
#include "BarChart.h"

using namespace std;

namespace sdds{
    void BarChart::init(const char* title, int noOfSampels, char fill){
        chartTitle = new char[strlen(title)+1];
        
        strcpy(chartTitle,title);

        chartSize = noOfSampels;
        fillChar=fill;
        bar = new Bar[noOfSampels];
        currSize=0;
    }

    void BarChart::add(const char* bar_title, int value){
        if(currSize < chartSize){
            bar[currSize].set(bar_title, fillChar, value);
            ++currSize;
        }
    }

    bool BarChart::isValid()const{
        for(int i=0; i<chartSize; ++i){
            if(!bar[i].isValid()) return false;
        }
        return true;
    }

    void BarChart::draw()const{
        if(currSize == chartSize && isValid()){
            cout<<chartTitle<<endl;
            for(int i=0; i<71; ++i)cout<<"-";
            cout<<endl;
            for(int i=0; i<chartSize; ++i)bar[i].draw();
            for(int i=0; i<71; ++i)cout<<"-";
            cout<<endl;
        }
        else{
            cout<<"Invalid Chart!\n";
        }
    }

    void BarChart::deallocate(){
        delete[] chartTitle;
        delete[] bar;
    }
}