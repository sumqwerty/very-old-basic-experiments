#include "Car.h"
#include <cstring>
#include <iostream>
#include <iomanip>

using namespace std;

namespace sdds{
    Car::Car(){
        resetInfo();
    }

    Car::Car(const char* type, const char* brand, const char* model, int year, int code, double price){
        if(type != nullptr && brand != nullptr && model != nullptr && year >= 1990 && code>99 && code<1000 && price>0){
            m_type = new char[20];
            strcpy(m_type,type);

            m_brand = new char[20];
            strcpy(m_brand,brand);

            m_model = new char[20];
            strcpy(m_model,model);

            m_year = year;
            m_code = code;
            m_price = price;

        }
        else{
            resetInfo();
        }
    }

    Car::~Car(){
        delete [] m_brand;
        delete [] m_type;
        delete [] m_model;
    }

    void Car::resetInfo(){
        m_type = nullptr;
        m_brand = nullptr;
        m_model = nullptr;
        m_year = 0;
        m_code = 0;
        m_price = 0;
    }

    Car &Car::setInfo(const char* type, const char* brand, const char* model, int year, int code, double price){
        delete [] m_brand;
        delete [] m_type;
        delete [] m_model;


        if(type != nullptr && brand != nullptr && model != nullptr && year >= 1990 && code>99 && code<1000 && price>0){
            m_type = new char[20];
            strcpy(m_type,type);

            m_brand = new char[20];
            strcpy(m_brand,brand);

            m_model = new char[20];
            strcpy(m_model,model);

            m_year = year;
            m_code = code;
            m_price = price;

        }
        else{
            resetInfo();
        }

        return *this;   
    }


    void Car::printInfo() const{
        cout<<"| "<<m_type;
        for(int i=strlen(m_type); i<=10; ++i)cout<<" ";

        cout<<"| "<<m_brand;
        for(int i=strlen(m_brand); i<=16; ++i)cout<<" ";

        cout<<"| "<<m_model;
        for(int i=strlen(m_model); i<=16; ++i)cout<<" ";

        cout<<"| "<<m_year<<" ";
        cout<<"|  "<<m_code<<" ";

        if(m_price<10)cout<<"|      "<<fixed<<setprecision(2)<<m_price<<" |\n";
        else if(m_price<100)cout<<"|     "<<fixed<<setprecision(2)<<m_price<<" |\n";
        else if(m_price<1000)cout<<"|    "<<fixed<<setprecision(2)<<m_price<<" |\n";
        else if(m_price<10000)cout<<"|   "<<fixed<<setprecision(2)<<m_price<<" |\n";
        else cout<<"|  "<<fixed<<setprecision(2)<<m_price<<" |\n";
    }

    bool Car::isValid()const {
        if(m_type != nullptr && m_brand != nullptr && m_model != nullptr && m_year >= 1990 && m_code>99 && m_code<1000 && m_price>0)
            return true;
        return false;
    }

    bool Car::isSimilarTo(const Car& car) const{
        if(strcmp(m_type,car.m_type)==0 && strcmp(m_brand,car.m_brand)==0 && strcmp(m_model,car.m_model)==0)return true;
        return false;
    }

    bool has_similar(const Car car[], const int num_cars){
        for (int i = 0; i < num_cars; i++){
            for (int j = i+1; j < num_cars; j++){
                if(car[i].isValid() && car[j].isValid())
                    if (car[i].isSimilarTo(car[j])) return true;
            }
        }
        return false;
    }

    bool has_invalid(const Car car[], const int num_cars){
        for (int i = 0; i < num_cars; i++){
            if(car[i].isValid() == false)return true;
        }
        return false;
    }

    void print(const Car car[], const int num_cars){
        for (int i = 0; i < num_cars; i++){
            if(car[i].isValid()){
                car[i].printInfo();
            }
        }
    }
}