#include "CleanerBot.h"
#include <cstring>
#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;
    


namespace sdds{
    void CleanerBot::setEmpty(){
        location = (char*)"";
        battery = 0;
        brush = 0;
        active=false;

    }
    CleanerBot::CleanerBot(){
        setEmpty();
    }

    CleanerBot::CleanerBot(const char* _location, double _battery, int _brush, bool _active){
        if(_location != nullptr && strlen(_location)>1 && _battery >=0 && _brush>=0){
            //location = new char[50];
            //strcpy(location,_location);
            location = (char*)_location;
            battery = _battery;
            brush = _brush;
            active = _active;
        }
        else{
            setEmpty();
        }
    }


    CleanerBot::~CleanerBot(){
        //delete [] location;
    }

    void CleanerBot::set(const char* _location, double _battery, int _brush, bool _active){
        if(_location != nullptr && strlen(_location)>1 && _battery >=0 && _brush>=0){
            //location = new char[50];
            //strcpy(location,_location);
            location = (char*)_location;
            battery = _battery;
            brush = _brush;
            active = _active;
        }
        else{
            setEmpty();
        }
    }
    void CleanerBot::setLocation(const char* _location){
        if(_location != nullptr && strlen(_location)>1){
            //delete [] location;
            //location = new char[50];
            //strcpy(location,_location);
            location = (char*)_location;
        }
    }
    
    void CleanerBot::setActive(bool _active){
        active = _active;
    };

    char* CleanerBot::getLocation()const{
        return location;
    }
    double CleanerBot::getBattery()const{
        return battery;
    }
    int CleanerBot::getBrush()const{
        return brush;
    }
    bool CleanerBot::isActive()const{
        return active;
    }
    bool CleanerBot::isValid()const{
        if(location != nullptr && strlen(location)>1 && battery >=0 && brush>=0)return true;
        return false;
    }

    void CleanerBot::display()const{
        cout << fixed << setprecision(1);
        int curr = 1 + strlen(location);
        cout<<"| "<<location;
        for(int i=curr; i<12; ++i)cout<<" ";
        cout<<"|";
        
        //4 2
        if(battery >= 100)cout<<"   "<<100.00<<" ";
        else if(battery >= 10)cout<<"    "<<battery<<" ";
        else cout<<"     "<<battery<<" ";
        cout<<"|";
        
        //20 //18 1
        if(brush < 10){
            for(int i=0; i<18; ++i)cout<<" ";
            cout<<brush;
        }
        else{
            for(int i=0; i<17; ++i)cout<<" ";
            cout<<brush;
        }
        cout<<" | ";
        if(active == false)cout<<"NO     ";
        else cout<<"YES    ";
        cout<<"|";
        cout<<endl;
    }

    int report(CleanerBot* bot, short num_bots){
        
        cout<<"         ------ Cleaner Bots Report -----\n";
        cout<<"     ---------------------------------------\n";
        int lowB = 0;
        cout<<"| Location   | Battery |  Number of Brushes | Active |\n";
        cout<<"|------------+---------+--------------------+--------|\n";

        vector<CleanerBot> arr;
        
        for(int i=0; i<num_bots; ++i){
            if(bot[i].isValid()){
                bot[i].display();
                if(bot[i].getBattery() < 30)++lowB;
                //CleanerBot temp;
                //temp = CleanerBot(bot[i].getLocation(),bot[i].getBattery(),bot[i].getBrush(),bot[i].isValid());
                arr.push_back(bot[i]);
            }
        }
        cout<<endl;
        cout<<"|====================================================|\n";
        cout<<"| LOW BATTERY WARNING:                               |\n";
        cout<<"|====================================================|\n";
        cout<<"| Number of robots to be charged: "<<lowB<<"                  |\n";
        cout<<"| Sorting robots based on their available power:     |\n";
        cout<<"| Location   | Battery |  Number of Brushes | Active |\n";
        cout<<"|------------+---------+--------------------+--------|\n";


        // for(int i=0; i<(int)arr.size(); ++i){
        //     arr.at(i).display();
        // }


        // CleanerBot *temp = &bot[0];
        // bot[0] = bot[1];
        // bot[1] = *temp;
        // delete [] temp;

        CleanerBot temp;
        for(int i = 0; i < (int)(arr.size()) - 1; i++)
        {
            for (int j = 0; j < (int)(arr.size()) - i - 1; j++){
                if (arr.at(j).getBattery() < arr.at(j+1).getBattery()) {
                    // swap arr[j+1] and arr[j]
                    temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }


            }
        }



        for(int i=0; i<(int)(arr.size()); ++i){
            if(arr[i].isValid()){
                arr[i].display();
            }
        }
        cout<<"|====================================================|\n";
        return 1;
    }

    

}