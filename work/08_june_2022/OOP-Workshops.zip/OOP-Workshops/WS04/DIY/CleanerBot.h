#ifndef SDDS_CLEANERBOT_H_
#define SDDS_CLEANERBOT_H_
namespace sdds {
    class CleanerBot{
        private:
            char *location;
            double battery;
            int brush;
            bool active;
            void setEmpty();
        public:
            CleanerBot();
            CleanerBot(const char* _location, double _battery, int _brush, bool _active);

            ~CleanerBot();

            void set(const char* _location, double _battery, int _brush, bool _active);
            void setLocation(const char* _location);
            void setActive(bool _active);

            char* getLocation()const;
            double getBattery()const;
            int getBrush()const;
            bool isActive()const;
            bool isValid()const;
            void display()const;
    };
    int report(CleanerBot* bot, short num_bots);


}
#endif 