public class Main {
    public static void main(String[] args) {
        Activity1.driver();
        Activity2.driver();
        Activity3.driver();
        Activity4.driver();
        Activity5.driver();
        Activity6.driver();
        Activity7.driver();
    }
}