function showTip(ele) {
    ele.style.visibility = "visible";
};
function resetTip(ele) {
    ele.style.visibility = "hidden";
    ele.style.transition = "0s";
    ele.style.opacity = "1";
};