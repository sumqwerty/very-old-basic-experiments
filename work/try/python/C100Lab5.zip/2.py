minutes = int(input("Input minutes to convert to seconds: "))
print(str(minutes)+" minutes is "+str(minutes*60)+" seconds")
