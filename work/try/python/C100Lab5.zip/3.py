fname = input("First Name: ")
lname = input("Last Name: ")

if fname == "Yatanajit" and lname == "Sidhu":
    print("Your name is the same as my name!")

elif fname == "Yatanajit":
    print("Your first name is the same as mine!")

elif lname == "Sidhu":
    print("Your last name is the same as mine!")
