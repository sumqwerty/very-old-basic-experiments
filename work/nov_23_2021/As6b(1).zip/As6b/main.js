'use strict';
/*
	WEB 230 Spring 2020
	Assignment 6b
	{your name here}
*/
