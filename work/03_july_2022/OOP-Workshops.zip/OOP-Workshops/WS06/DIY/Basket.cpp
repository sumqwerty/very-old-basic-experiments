#include<iostream>
#include<cstring>
#include <iomanip>
#include <ostream>
#include"Basket.h"

using namespace std;


namespace sdds{
    Basket::Basket(){
        m_cnt=0;
        m_price=0;
        m_fruits=nullptr;
    }

    Basket::Basket(Fruit *fArry, int _len, double _price){
        m_fruits = new Fruit[_len];
        int temp=0;
        for(int i=0; i<_len; ++i){
            if(fArry[i].m_qty > 0 && fArry[i].m_name != nullptr){
                //cout<<"helloooooooooooooooooooooooooooooooo"<<endl;
                strcpy(m_fruits[i].m_name,fArry[i].m_name);
                m_fruits[i].m_qty = fArry[i].m_qty;
                temp++;
            }
        }
        m_cnt = temp;
        m_price=_price;
    }

    Basket::Basket(Basket &obj){
        m_cnt = obj.m_cnt;
        m_price = obj.m_price;
        m_fruits = new Fruit[obj.m_cnt];

        for(int i=0; i<m_cnt; ++i){
            strcpy(m_fruits[i].m_name,obj.m_fruits[i].m_name);
            m_fruits[i].m_qty = obj.m_fruits[i].m_qty;
        }
    }

    Basket& Basket::operator=(const Basket& obj){
        m_cnt = obj.m_cnt;
        m_price = obj.m_price;
        if(m_fruits != nullptr){
            delete [] m_fruits;
        }
        m_fruits = new Fruit[obj.m_cnt];

        for(int i=0; i<m_cnt; ++i){
            strcpy(m_fruits[i].m_name,obj.m_fruits[i].m_name);
            m_fruits[i].m_qty = obj.m_fruits[i].m_qty;
        }
        return *this;
    }

    Basket::~Basket(){
        delete [] m_fruits;
    }

    void Basket::setPrice(double price){
        m_price = price;
    }

    Basket::operator bool() const{
        if(m_cnt > 0)return true;
        return false;
    }

    void Basket::resize(){
        int newSize = m_cnt+1;
        Fruit* newArr = new Fruit[newSize];

        memcpy( newArr, m_fruits, m_cnt * sizeof(Fruit) );

        m_cnt = newSize;
        delete [] m_fruits;
        m_fruits = newArr;
    }

    Basket& Basket::operator+=(const Fruit obj){
        resize();
        strcpy(m_fruits[m_cnt-1].m_name,obj.m_name);
        m_fruits[m_cnt-1].m_qty = obj.m_qty;
        return *this;
    }

    std::ostream& operator<<(std::ostream &os, const Basket& obj){
        if(obj.m_cnt){
            os<<"Basket Content:"<<endl;
            for(int i=0; i<obj.m_cnt; ++i){ 
                os<< std::right << std::setw(10)<<obj.m_fruits[i].m_name;
                os<<": "<<fixed<<setprecision(2) <<obj.m_fruits[i].m_qty<<"kg"<<endl;
            }
            os<<"Price: "<<fixed<<setprecision(2)<<obj.m_price<<endl;
        }
        else{
            os<<"The basket is empty!"<<endl;
        }
        return os;
    }



} // namespace sdds
