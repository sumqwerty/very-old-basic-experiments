#ifndef SDDS_BASKET_H_
#define SDDS_BASKET_H_
#include <iostream>
namespace sdds {
    struct Fruit{
        char m_name[30 + 1]; // the name of the fruit
        double m_qty;        // quantity in kilograms
    };

    class Basket{
        private:
            Fruit *m_fruits;
            int m_cnt;
            double m_price;
        
        public:
            Basket();
            Basket(Fruit *fArry, int _len, double _price);
            Basket(Basket &obj);
            Basket& operator=(const Basket& obj);
            ~Basket();
            void setPrice(double price);
            operator bool() const;
            Basket& operator+=(const Fruit obj);
            friend std::ostream& operator<<(std::ostream &os, const Basket& obj);
            void resize();
    };
}
#endif 